#ifndef VERSION_H
#define VERSION_H

#define VERSION_MAJOR 1
#define VERSION_MINOR 11
#define VERSION_PATCH 4

#endif // VERSION_H
