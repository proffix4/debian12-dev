<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Gelen Kutusu</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Arşivler</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Taslaklar</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Gönderildi</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Şablonlar</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Önemsiz</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Çöp</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Gönderilmemiş Mesajlar</translation>
    </message>
</context>
</TS>
