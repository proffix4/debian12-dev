<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Εισερχόμενα</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Αρχείο</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Προσχέδια</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Απεσταλμένα</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Πρότυπα</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Ανεπιθύμητα</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Απορρίμματα</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Εξερχόμενα</translation>
    </message>
</context>
</TS>
