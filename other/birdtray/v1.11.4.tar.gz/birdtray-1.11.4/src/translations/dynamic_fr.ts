<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Boîte de réception</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archives</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Brouillons</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Éléments envoyés</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Modèles</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Spam</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Corbeille</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Boîte d'envoi</translation>
    </message>
</context>
</TS>
