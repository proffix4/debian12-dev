<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Inkorgen</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Arkiv</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Utkast</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Skickat</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Mallar</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Skräp</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papperskorgen</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Utkorgen</translation>
    </message>
</context>
</TS>
