<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Входящие</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Архивы</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Черновики</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Отправленные</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Шаблоны</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Спам</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Удалённые</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Исходящие</translation>
    </message>
</context>
</TS>
