<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Postvak IN</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archief</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Concepten</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Verzonden</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Sjablonen</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Ongewenste e-mail</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Prullenbak</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Niet-verzonden berichten</translation>
    </message>
</context>
</TS>
