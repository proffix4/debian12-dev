<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Arquivado</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Rascunhos</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Enviados</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Modelos</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Spam</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Lixeira</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Mensagens não enviadas</translation>
    </message>
</context>
</TS>
