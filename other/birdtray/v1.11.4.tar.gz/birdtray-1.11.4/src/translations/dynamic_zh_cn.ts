<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>收件箱</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>归档</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>草稿</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>已发送消息</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>模板</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>垃圾</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>废件箱</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>未发送消息</translation>
    </message>
</context>
</TS>
