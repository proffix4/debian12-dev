<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>In Arrivo</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archivio</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Bozze</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Inviata</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Modelli</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Indesiderata</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Cestino</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Messaggi non Inviati</translation>
    </message>
</context>
</TS>
