<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Bandeja de entrada</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archivados</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Borradores</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Enviados</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Plantillas</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>No deseados</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Bandeja de salida</translation>
    </message>
</context>
</TS>
