<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Inbox</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archives</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Drafts</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Sent</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Templates</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Junk</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Trash</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Unsent Messages</translation>
    </message>
</context>
</TS>
