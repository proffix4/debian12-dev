<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Posteingang</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archiv</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Entwürfe</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Gesendet</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Vorlagen</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Junk</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Papierkorb</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Postausgang</translation>
    </message>
</context>
</TS>
