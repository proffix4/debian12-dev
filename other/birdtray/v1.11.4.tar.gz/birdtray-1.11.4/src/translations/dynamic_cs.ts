<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Doručená pošta</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archivy</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Pracovní verze</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Odeslaná</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Šablony</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Nevyžádaná</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Neodeslané zprávy</translation>
    </message>
</context>
</TS>
