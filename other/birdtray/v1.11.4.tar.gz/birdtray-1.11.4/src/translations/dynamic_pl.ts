<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>EmailFolders</name>
    <message>
        <source>Inbox</source>
        <translation>Skrzynka Odbiorcza</translation>
    </message>
    <message>
        <source>Archives</source>
        <translation>Archiwa</translation>
    </message>
    <message>
        <source>Drafts</source>
        <translation>Wersje Robocze</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Wysłane</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Szablony</translation>
    </message>
    <message>
        <source>Junk</source>
        <translation>Spam</translation>
    </message>
    <message>
        <source>Trash</source>
        <translation>Kosz</translation>
    </message>
    <message>
        <source>Unsent Messages</source>
        <translation>Niewysłane</translation>
    </message>
</context>
</TS>
