# https://github.com/wxWidgets/wxWidgets/archive/refs/tags/v3.2.5.tar.gz
mkdir buildgtk
cd buildgtk
#../configure --with-gtk
../configure --with-gtk --disable-shared --enable-monolithic
make -j8
sudo make install
sudo ldconfig
